# approveDoc — Document Viewer

A lightweight PDF document viewer backed by Supabase storage, using the Mozilla pdf.js viewer for thumbnails, search, bookmarks, and full PDF navigation.

---

## Project structure

```
approveDoc-viewer/
├── index.html          Main application
├── css/
│   └── viewer.css      Styles
├── js/
│   ├── config.js       ← Edit this to configure for your project
│   └── app.js          Application logic
├── pdfjs/              ← Drop the pdf.js dist contents here (see below)
│   └── web/
│       └── viewer.html
└── README.md
```

---

## Setup

### 1. Add pdf.js (required for thumbnails & full viewer)

1. Download the latest prebuilt release from:
   https://github.com/mozilla/pdf.js/releases
   (download `pdfjs-x.x.x-dist.zip`)

2. Unzip it and copy the contents into the `pdfjs/` folder in this project,
   so the path `pdfjs/web/viewer.html` exists.

3. In `js/config.js`, set:
   ```js
   pdfViewerUrl: 'pdfjs/web/viewer.html',
   ```

### 2. Configure for your project

Open `js/config.js` and update the values at the top:

| Setting       | Description                              |
|---------------|------------------------------------------|
| `supabaseUrl` | Your Supabase project URL                |
| `supabaseAnon`| Your Supabase anon/public key            |
| `bucket`      | Storage bucket name                      |
| `tableDocs`   | Parent document table name               |
| `tableFiles`  | File references table name               |
| `colDocId`    | Primary key column on tableDocs          |
| `colDocDesc`  | Description column on tableDocs          |

### 3. Supabase requirements

The following must exist in your Supabase project:

**Tables** (see migrations below):
- `tableDocs` with columns: `colDocId` (UUID PK), `colDocDesc` (text)
- `tableFiles` with columns: `docfile_id` (UUID PK), `colDocId` (UUID FK), `file_name`, `file_path`, `file_size`, `mime_type`, `uploaded_at`

**Storage bucket**: must exist and be set to public

**RLS policies**: both tables and `storage.objects` need open policies for anon/authenticated (or appropriate auth-based policies for production).

### 4. Hosting

The project includes server config files for each platform — no manual server setup needed:

| File | Platform |
|------|----------|
| `web.config` | IIS (local dev, Windows Server) |
| `.htaccess` | Apache (Namecheap shared hosting) |
| CSP `<meta>` in `index.html` | All platforms (fallback) |

**Local IIS**: point a site at the project folder — `web.config` handles MIME types automatically.

**Namecheap**: upload all files via FTP, `.htaccess` handles everything.

**AWS / other**: no config files needed for S3+CloudFront. Set MIME types in the S3 bucket or CloudFront distribution, and add the CSP as a CloudFront response headers policy.

### 4b. Moving between platforms

- **Local IIS**: point a site at the project folder. No build step needed.
- **Production**: deploy the whole folder to any static web host (Netlify, Vercel, Azure Static Web Apps, etc.)
- **GitHub**: commit the folder, connect to your hosting provider.

> Note: the pdf.js viewer uses `?file=` query parameter to load documents.
> This must be served over HTTP/HTTPS — opening index.html directly as a
> `file://` URL will block cross-origin requests.

---

## Database migrations (approveDoc / test tables)

```sql
CREATE TABLE IF NOT EXISTS test_document (
  testdoc_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  testdoc_description TEXT
);

CREATE TABLE IF NOT EXISTS test_docfiles (
  docfile_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  testdoc_id UUID NOT NULL REFERENCES test_document(testdoc_id) ON DELETE CASCADE,
  file_name TEXT NOT NULL,
  file_path TEXT NOT NULL,
  file_size BIGINT,
  mime_type TEXT,
  uploaded_at TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_test_docfiles_testdoc_id ON test_docfiles(testdoc_id);
ALTER TABLE test_document ENABLE ROW LEVEL SECURITY;
ALTER TABLE test_docfiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "allow_all_test_document" ON test_document
  FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

CREATE POLICY "allow_all_test_docfiles" ON test_docfiles
  FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

-- Storage
UPDATE storage.buckets SET public = true WHERE id = 'test_docfiles';

CREATE POLICY "allow_anon_select" ON storage.objects
  FOR SELECT TO anon, authenticated USING (bucket_id = 'test_docfiles');

CREATE POLICY "allow_anon_insert" ON storage.objects
  FOR INSERT TO anon, authenticated WITH CHECK (bucket_id = 'test_docfiles');
```
