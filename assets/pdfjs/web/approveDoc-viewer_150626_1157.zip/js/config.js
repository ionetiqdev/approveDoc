// ════════════════════════════════════════════════════════════════════
// CONFIG — update these values when reusing in a new project
// ════════════════════════════════════════════════════════════════════

const CONFIG = {

  // Supabase connection
  supabaseUrl:  'https://fjqgbpbqaucnbrgeuqol.supabase.co',
  supabaseAnon: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZqcWdicGJxYXVjbmJyZ2V1cW9sIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODE0NTgyNDEsImV4cCI6MjA5NzAzNDI0MX0.Gru6x-e2TfKNparWqKVQSO3nl2n222ocBJuCN0lnWBA',

  // Storage
  bucket: 'test_docfiles',

  // Database tables & columns
  tableDocs:    'test_document',        // parent document table
  tableFiles:   'test_docfiles',        // file references table
  colDocId:     'testdoc_id',           // PK on tableDocs
  colDocDesc:   'testdoc_description',  // description column on tableDocs

  // pdf.js viewer path (relative to index.html)
  // Point this at your local pdfjs/web/viewer.html once you have the dist files,
  // or leave as the CDN fallback below.
  //
  // Local pdfjs dist (viewer.mjs must have validateFileURL bypassed — see README)
  pdfViewerUrl: 'pdfjs/web/viewer.html',

};
