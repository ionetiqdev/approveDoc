// ── Preferences ───────────────────────────────────────────────────────
// Only settings that can be changed live (via URL hash reload or DOM)
// are shown here. PDF toolbar button visibility cannot be toggled live —
// see viewer-features.json for instructions on editing those.

const PREFS_KEY = 'approveDoc_viewer_prefs';

const PREF_MAP = [
  // Application tab
  { id: 'pref-sidebar-enabled',     path: 'sidebar.enabled',           type: 'bool'   },
  { id: 'pref-sidebar-defaultOpen', path: 'sidebar.defaultOpen',       type: 'bool'   },
  { id: 'pref-search-enabled',      path: 'search.enabled',            type: 'bool'   },
  { id: 'pref-upload-modalButton',  path: 'upload.modalButton',        type: 'bool'   },
  { id: 'pref-upload-dropZone',     path: 'upload.dropZone',           type: 'bool'   },
  { id: 'pref-delete-enabled',      path: 'delete.enabled',            type: 'bool'   },
  // Document Viewer tab — only URL hash params
  { id: 'pref-pdf-defaultZoom',     path: 'pdfViewer.defaultZoom',     type: 'select' },
  { id: 'pref-pdf-defaultPanel',    path: 'pdfViewer.defaultPanel',    type: 'select' },
  { id: 'pref-pdf-showToolbar',     path: 'pdfViewer.showToolbar',     type: 'bool'   },
  { id: 'pref-pdf-showNavPanes',    path: 'pdfViewer.showNavPanes',    type: 'bool'   },
];

function getPath(obj, path) {
  return path.split('.').reduce((o, k) => o?.[k], obj);
}

function setPath(obj, path, value) {
  const keys = path.split('.');
  const last = keys.pop();
  const target = keys.reduce((o, k) => { o[k] = o[k] || {}; return o[k]; }, obj);
  target[last] = value;
}

function deepMerge(base, override) {
  const result = Object.assign({}, base);
  for (const key of Object.keys(override || {})) {
    if (typeof override[key] === 'object' && override[key] !== null && !Array.isArray(override[key])) {
      result[key] = deepMerge(base[key] || {}, override[key]);
    } else {
      result[key] = override[key];
    }
  }
  return result;
}

function loadSavedPrefs() {
  try { return JSON.parse(localStorage.getItem(PREFS_KEY) || '{}'); } catch(e) { return {}; }
}

function savePrefs(prefs) {
  try { localStorage.setItem(PREFS_KEY, JSON.stringify(prefs)); } catch(e) {}
}

function mergePrefsIntoFeatures() {
  const saved = loadSavedPrefs();
  if (Object.keys(saved).length) {
    Object.assign(FEATURES, deepMerge(FEATURES, saved));
  }
}

function populatePrefsModal() {
  for (const { id, path, type } of PREF_MAP) {
    const el = document.getElementById(id);
    if (!el) continue;
    const val = getPath(FEATURES, path);
    if (type === 'select') el.value = val ?? '';
    else el.checked = val !== false;
  }
}

function readPrefsFromModal() {
  const prefs = {};
  for (const { id, path, type } of PREF_MAP) {
    const el = document.getElementById(id);
    if (!el) continue;
    setPath(prefs, path, type === 'select' ? el.value : el.checked);
  }
  return prefs;
}

function reloadPdfFrame() {
  const frame = document.getElementById('pdf-frame');
  if (frame && window._currentPdfBlob) {
    const hash = buildPdfHash(currentFileUrl);
    frame.src = `${CONFIG.pdfViewerUrl}?file=${encodeURIComponent(window._currentPdfBlob)}#${hash}`;
  }
}

function applyAndReload(prefs) {
  Object.assign(FEATURES, deepMerge(FEATURES, prefs));
  applyFeatures();
  reloadPdfFrame();
}

function resetPrefs() {
  localStorage.removeItem(PREFS_KEY);
  if (window._defaultFeatures) {
    Object.assign(FEATURES, JSON.parse(JSON.stringify(window._defaultFeatures)));
  }
  applyFeatures();
  populatePrefsModal();
  reloadPdfFrame();
  toast('Preferences reset to defaults');
}

// ── Wire up modal ─────────────────────────────────────────────────────
document.getElementById('prefsModal').addEventListener('show.bs.modal', populatePrefsModal);

document.getElementById('prefs-save').addEventListener('click', () => {
  const prefs = readPrefsFromModal();
  savePrefs(prefs);
  applyAndReload(prefs);
  bootstrap.Modal.getInstance(document.getElementById('prefsModal')).hide();
  toast('Preferences saved');
});

document.getElementById('prefs-reset').addEventListener('click', () => {
  if (confirm('Reset all preferences to defaults?')) resetPrefs();
});

// Called by app.js after FEATURES is loaded from JSON
window.onFeaturesLoaded = function() {
  window._defaultFeatures = JSON.parse(JSON.stringify(FEATURES));
  mergePrefsIntoFeatures();
  applyFeatures();
};
