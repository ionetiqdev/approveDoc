// ── Load feature config then initialise ──────────────────────────────
let FEATURES = {};

// Safe defaults used if viewer-features.json fails to load
const DEFAULT_FEATURES = {
  sidebar:    { enabled: true, defaultOpen: true },
  upload:     { enabled: true, dropZone: true, modalButton: true },
  delete:     { enabled: true },
  search:     { enabled: true },
  branding:   { appName: 'approveDoc', appSubtitle: 'document viewer' },
  pdfViewer:  { defaultZoom: 'page-fit', defaultPanel: 'thumbs', showToolbar: true, showNavPanes: true },
  pdfButtons: { rotate: true, annotationEditor: true, print: true, download: true, openFile: false, viewBookmark: false, documentProperties: false, presentationMode: false }
};

async function loadFeatures() {
  try {
    const res = await fetch('viewer-features.json');
    if (!res.ok) throw new Error('HTTP ' + res.status);
    FEATURES = await res.json();
  } catch(e) {
    console.warn('viewer-features.json not loaded, using defaults:', e.message);
    FEATURES = JSON.parse(JSON.stringify(DEFAULT_FEATURES));
  }
  applyFeatures();
  if (window.onFeaturesLoaded) window.onFeaturesLoaded();
  initApp();
}

function applyFeatures() {
  const f = FEATURES;

  // Branding
  if (f.branding) {
    const brand = document.querySelector('.brand');
    if (brand) brand.innerHTML = `${f.branding.appName || 'approveDoc'}<span> </span><span class="brand-sub">/ ${f.branding.appSubtitle || 'document viewer'}</span>`;
  }

  // Sidebar
  if (f.sidebar) {
    const sidebar = document.getElementById('sidebar');
    if (!f.sidebar.enabled) {
      sidebar.style.display = 'none';
    } else if (!f.sidebar.defaultOpen) {
      sidebar.classList.add('collapsed');
    }
  }

  // Upload — modal button
  const newDocBtn = document.getElementById('new-doc-btn');
  if (newDocBtn && f.upload) {
    newDocBtn.style.display = (f.upload.enabled && f.upload.modalButton) ? '' : 'none';
  }

  // Upload — drop zone
  const dropWrap = document.getElementById('drop-zone-wrap');
  if (dropWrap && f.upload) {
    dropWrap.style.display = (f.upload.enabled && f.upload.dropZone) ? '' : 'none';
  }

  // Search
  const searchWrap = document.getElementById('search-wrap');
  if (searchWrap) searchWrap.style.display = f.search?.enabled ? '' : 'none';
}

// ── Build pdf.js URL hash ─────────────────────────────────────────────
// These are the hash params pdf.js actually supports via URL:
//   pagemode = thumbs | outline | attachments | layers | none
//   zoom     = page-fit | page-width | page-height | auto | <number>
//   toolbar  = 0 | 1
//   navpanes = 0 | 1
//   page     = <n>
function buildPdfHash(fileUrl) {
  const v = FEATURES.pdfViewer || {};

  const pagemode = v.defaultPanel || 'thumbs';
  const zoom     = v.defaultZoom  || 'page-fit';
  const toolbar  = v.showToolbar  !== false ? 1 : 0;
  const navpanes = v.showNavPanes !== false ? 1 : 0;

  return [
    'page=1',
    `zoom=${zoom}`,
    `pagemode=${pagemode}`,
    `toolbar=${toolbar}`,
    `navpanes=${navpanes}`,
    'locale=en-US',
  ].join('&');
}

// ── Supabase client ───────────────────────────────────────────────────
const sb = supabase.createClient(CONFIG.supabaseUrl, CONFIG.supabaseAnon, {
  auth: { persistSession: false, detectSessionInUrl: false, autoRefreshToken: false }
});

// ── State ─────────────────────────────────────────────────────────────
let allDocs       = [];
let currentDocId  = null;
let currentFileUrl = null;

// ── Elements ──────────────────────────────────────────────────────────
const sidebar       = document.getElementById('sidebar');
const docList       = document.getElementById('doc-list');
const docSearch     = document.getElementById('doc-search');
const emptyState    = document.getElementById('empty-state');
const viewerToolbar = document.getElementById('viewer-toolbar');
const viewerDocName = document.getElementById('viewer-doc-name');
const pdfFrame      = document.getElementById('pdf-frame');
const dropZone      = document.getElementById('drop-zone');
const fileInput     = document.getElementById('file-input');

// ── Toast ─────────────────────────────────────────────────────────────
function toast(msg, type = 'success') {
  const wrap = document.getElementById('toast-wrap');
  const el = document.createElement('div');
  el.className = `alert alert-${type} py-2 px-3 mb-0 shadow-sm`;
  el.style.cssText = 'font-size:0.82rem;min-width:220px;border-radius:10px;';
  el.textContent = msg;
  wrap.appendChild(el);
  setTimeout(() => el.remove(), 3500);
}

// ── Sidebar toggle ────────────────────────────────────────────────────
document.getElementById('toggle-sidebar').addEventListener('click', () => {
  sidebar.classList.toggle('collapsed');
});

// ── Load document list ────────────────────────────────────────────────
async function loadDocuments() {
  const { data, error } = await sb
    .from(CONFIG.tableDocs)
    .select(`${CONFIG.colDocId}, ${CONFIG.colDocDesc}, ${CONFIG.tableFiles}(docfile_id, file_name, file_path, mime_type, uploaded_at)`)
    .order(CONFIG.colDocId);

  if (error) { toast('Failed to load documents', 'danger'); return; }
  allDocs = data || [];
  renderDocList(allDocs);
}

function renderDocList(docs) {
  if (!docs.length) {
    docList.innerHTML = `
      <div class="empty-state py-4">
        <i class="bi bi-folder2-open" style="font-size:2rem"></i>
        <p>No documents yet.<br>Upload a PDF to get started.</p>
      </div>`;
    return;
  }
  const showDelete = FEATURES.delete?.enabled !== false;
  docList.innerHTML = docs.map(d => `
    <div class="doc-item ${d[CONFIG.colDocId] === currentDocId ? 'active' : ''}"
         data-id="${d[CONFIG.colDocId]}">
      <div class="d-flex align-items-center gap-2">
        <div class="doc-title flex-grow-1"
             onclick="selectDoc('${d[CONFIG.colDocId]}')"
             style="cursor:pointer">
          ${d[CONFIG.colDocDesc] || 'Untitled document'}
        </div>
        ${showDelete ? `
        <button class="btn-icon btn flex-shrink-0" title="Delete"
                onclick="deleteDoc('${d[CONFIG.colDocId]}', event)">
          <i class="bi bi-trash" style="font-size:13px;color:#94a3b8"></i>
        </button>` : ''}
      </div>
    </div>`
  ).join('');
}

if (docSearch) {
  docSearch.addEventListener('input', () => {
    const q = docSearch.value.toLowerCase();
    renderDocList(allDocs.filter(d =>
      (d[CONFIG.colDocDesc] || '').toLowerCase().includes(q)
    ));
  });
}

// ── Inject CSS into pdf.js iframe ────────────────────────────────────
// Fixes white-on-white colours AND hides buttons per viewer-features.json
function injectPdfStyles() {
  try {
    const doc = pdfFrame.contentDocument || pdfFrame.contentWindow.document;
    if (!doc || doc.getElementById('approvedoc-patch')) return;

    const b = FEATURES.pdfButtons || {};

    // Map feature flag → CSS selector(s) to hide
    const hideRules = [
      { key: 'rotate',             selectors: ['#rotateCcwButton', '#rotateCwButton'] },
      { key: 'annotationEditor',   selectors: ['#editorFreeTextButton', '#editorInkButton', '#editorStampButton', '#editorHighlightButton'] },
      { key: 'print',              selectors: ['#printButton'] },
      { key: 'download',           selectors: ['#downloadButton', '#secondaryDownloadButton'] },
      { key: 'openFile',           selectors: ['#openFileButton'] },
      { key: 'viewBookmark',       selectors: ['#viewBookmarkButton'] },
      { key: 'documentProperties', selectors: ['#documentPropertiesButton'] },
      { key: 'presentationMode',   selectors: ['#presentationModeButton'] },
      { key: 'spreadOdd',          selectors: ['#spreadOddButton'] },
      { key: 'spreadEven',         selectors: ['#spreadEvenButton'] },
      { key: 'scrollWrapped',      selectors: ['#scrollWrappedButton'] },
      { key: 'scrollPage',         selectors: ['#scrollPageButton'] },
    ];

    const hideCss = hideRules
      .filter(r => b[r.key] === false)
      .map(r => r.selectors.join(', ') + ' { display: none !important; }')
      .join('\n');

    const style = doc.createElement('style');
    style.id = 'approvedoc-patch';
    style.textContent = `
      /* Colour fixes */
      #scaleSelect, #scaleSelect option,
      .dropdownToolbarButton > select,
      .dropdownToolbarButton > select option {
        color: #000 !important;
        background-color: #fff !important;
      }
      #secondaryToolbar, .secondaryToolbar,
      #secondaryToolbarButtonContainer {
        background-color: #fff !important;
        color: #333 !important;
        border: 1px solid #ccc !important;
        box-shadow: 0 2px 8px rgba(0,0,0,0.15) !important;
      }
      .secondaryToolbarButton,
      #secondaryToolbarButtonContainer button {
        color: #333 !important;
        background: transparent !important;
      }
      .secondaryToolbarButton:hover,
      #secondaryToolbarButtonContainer button:hover {
        background-color: #f0f0f0 !important;
      }
      .secondaryToolbarButton > span,
      #secondaryToolbarButtonContainer button > span {
        color: #333 !important;
      }
      #findbar { background: #f9f9f9 !important; color: #000 !important; }
      #findInput { color: #000 !important; background: #fff !important; }
      dialog, .dialog { color: #000 !important; }

      /* Button visibility from viewer-features.json */
      ${hideCss}
    `;
    doc.head.appendChild(style);
  } catch(e) {
    console.warn('Could not inject styles into pdf.js iframe:', e.message);
  }
}

// ── Select & view document ────────────────────────────────────────────
async function selectDoc(id) {
  currentDocId = id;
  renderDocList(allDocs.filter(d =>
    (d[CONFIG.colDocDesc] || '').toLowerCase().includes(docSearch?.value.toLowerCase() || '')
  ));

  const doc = allDocs.find(d => d[CONFIG.colDocId] === id);
  if (!doc) return;

  const files = doc[CONFIG.tableFiles] || [];
  const pdfFile = files[0];
  if (!pdfFile) { toast('No file attached to this document', 'warning'); return; }

  viewerDocName.textContent = doc[CONFIG.colDocDesc] || pdfFile.file_name;
  viewerToolbar.style.display = 'flex';

  const { data: publicData } = sb.storage
    .from(CONFIG.bucket)
    .getPublicUrl(pdfFile.file_path);

  currentFileUrl = publicData.publicUrl;

  document.getElementById('download-btn').onclick = () => {
    const a = document.createElement('a');
    a.href = currentFileUrl;
    a.download = pdfFile.file_name;
    a.click();
  };

  // Fetch PDF as blob so viewer.mjs validateFileURL never blocks it
  // (blob: URLs are always same-origin — no edits to viewer.mjs needed)
  let pdfBlobUrl;
  try {
    const resp = await fetch(currentFileUrl);
    if (!resp.ok) throw new Error('HTTP ' + resp.status);
    const blob = await resp.blob();
    // Revoke previous blob URL to free memory
    if (window._currentPdfBlob) URL.revokeObjectURL(window._currentPdfBlob);
    pdfBlobUrl = URL.createObjectURL(blob);
    window._currentPdfBlob = pdfBlobUrl;
  } catch(e) {
    toast('Could not fetch PDF: ' + e.message, 'danger');
    return;
  }

  const hash = buildPdfHash(currentFileUrl);
  emptyState.style.display = 'none';
  pdfFrame.style.display = 'block';
  pdfFrame.src = `${CONFIG.pdfViewerUrl}?file=${encodeURIComponent(pdfBlobUrl)}#${hash}`;

  // Inject colour/button fixes into pdf.js iframe after it loads
  pdfFrame.onload = injectPdfStyles;

  if (window.innerWidth < 768) sidebar.classList.add('collapsed');
}

// ── Delete document ───────────────────────────────────────────────────
async function deleteDoc(id, e) {
  e.stopPropagation();
  if (!confirm('Delete this document and its file?')) return;

  const doc = allDocs.find(d => d[CONFIG.colDocId] === id);
  const files = doc?.[CONFIG.tableFiles] || [];

  if (files.length) {
    await sb.storage.from(CONFIG.bucket).remove(files.map(f => f.file_path));
  }

  const { error } = await sb.from(CONFIG.tableDocs).delete().eq(CONFIG.colDocId, id);
  if (error) { toast('Delete failed: ' + error.message, 'danger'); return; }

  toast('Document deleted');

  if (currentDocId === id) {
    currentDocId  = null;
    currentFileUrl = null;
    pdfFrame.style.display = 'none';
    pdfFrame.src  = '';
    emptyState.style.display = 'flex';
    viewerToolbar.style.display = 'none';
  }

  await loadDocuments();
}

// ── Upload ────────────────────────────────────────────────────────────
async function uploadAndSave(description, file, progressBar, statusEl) {
  if (!file) { toast('Please select a PDF file', 'warning'); return; }

  const safeName = `${Date.now()}_${file.name.replace(/[^a-z0-9._-]/gi, '_')}`;

  if (statusEl) statusEl.textContent = 'Creating document record…';
  if (progressBar) progressBar.style.width = '15%';

  const { data: docData, error: docErr } = await sb
    .from(CONFIG.tableDocs)
    .insert({ [CONFIG.colDocDesc]: description || file.name })
    .select()
    .single();

  if (docErr) { toast('Failed to create record: ' + (docErr.message || docErr.code), 'danger'); return; }
  if (progressBar) progressBar.style.width = '35%';

  if (statusEl) statusEl.textContent = 'Uploading file…';
  const { error: upErr } = await sb.storage
    .from(CONFIG.bucket)
    .upload(safeName, file, { contentType: 'application/pdf', upsert: false });

  if (upErr) {
    toast('Upload failed: ' + upErr.message, 'danger');
    await sb.from(CONFIG.tableDocs).delete().eq(CONFIG.colDocId, docData[CONFIG.colDocId]);
    return;
  }
  if (progressBar) progressBar.style.width = '70%';

  if (statusEl) statusEl.textContent = 'Saving file reference…';
  const { error: fileErr } = await sb.from(CONFIG.tableFiles).insert({
    [CONFIG.colDocId]: docData[CONFIG.colDocId],
    file_name: file.name,
    file_path: safeName,
    file_size: file.size,
    mime_type: 'application/pdf'
  });

  if (fileErr) { toast('File reference failed: ' + fileErr.message, 'danger'); return; }

  if (progressBar) progressBar.style.width = '100%';
  if (statusEl) statusEl.textContent = 'Done!';

  toast('Document uploaded successfully');
  await loadDocuments();
  selectDoc(docData[CONFIG.colDocId]);
}

// ── Modal upload ──────────────────────────────────────────────────────
document.getElementById('modal-save').addEventListener('click', async () => {
  const desc    = document.getElementById('modal-description').value.trim();
  const file    = document.getElementById('modal-file').files[0];
  const progWrap = document.getElementById('modal-progress');
  const progBar  = document.getElementById('upload-progress-bar');
  const status   = document.getElementById('upload-status');
  const saveBtn  = document.getElementById('modal-save');

  progWrap.style.display = 'block';
  progBar.style.width = '0%';
  saveBtn.disabled = true;

  await uploadAndSave(desc, file, progBar, status);

  setTimeout(() => {
    bootstrap.Modal.getInstance(document.getElementById('addDocModal')).hide();
    document.getElementById('modal-description').value = '';
    document.getElementById('modal-file').value = '';
    progWrap.style.display = 'none';
    saveBtn.disabled = false;
  }, 600);
});

// ── Drop zone ─────────────────────────────────────────────────────────
if (dropZone) {
  dropZone.addEventListener('click', () => fileInput.click());
  dropZone.addEventListener('dragover', e => { e.preventDefault(); dropZone.classList.add('drag-over'); });
  dropZone.addEventListener('dragleave', () => dropZone.classList.remove('drag-over'));
  dropZone.addEventListener('drop', async e => {
    e.preventDefault();
    dropZone.classList.remove('drag-over');
    const file = e.dataTransfer.files[0];
    if (file && file.type === 'application/pdf') {
      await uploadAndSave(file.name.replace(/\.pdf$/i, ''), file, null, null);
    } else {
      toast('Only PDF files are supported', 'warning');
    }
  });
}

if (fileInput) {
  fileInput.addEventListener('change', async () => {
    const file = fileInput.files[0];
    if (file) await uploadAndSave(file.name.replace(/\.pdf$/i, ''), file, null, null);
  });
}

// ── Init ──────────────────────────────────────────────────────────────
function initApp() {
  loadDocuments();
}

loadFeatures();
